%% Load data
load('cellParams_Temp.mat'); % cell parameters
load('driveCycleData.mat'); % drive cycle data
load('tempCurrentLimLUT.mat'); % current limit data

%% Battery initialization
C_rate = 31;
SoC_init = [0.9,0.92,0.94];% initialize different SoC for balancing

%% Balancing initialization
R_bleed = 15; % parallel balancing resistor 
% SoC based balancing
BalSoCThld = 0.005; % end balancing when dSoC < BalSocThld 
% Voltage based balancing
BalVoltageThld = 0.005; % end balancing when dV < BalVoltageThld
% Debounce hysterisis range
EnBalVoltageThld = 0.008; % voltage threshold for entering balancing
ExBalVoltageThld = 0.004; % voltage threshold for existing balancing

%% CCCV initialization
CV_VoltageThld = 4.15; % voltage threshold CC -> CV
CV_CurrentThld = 0.02 * C_rate; % current threshold CC -> stop
CV_Gain = 1/(0.01 + 0.005); % approx 1/(R0+R1)
CC_Current = 0.5 * C_rate;

%% Fault monitoring limits initialization
% voltage limits
OverCellVoltageLim = 4.3; 
UnderCellVoltageLim = 2.7;
OverVoltageTLim = 3; % time threshold for indicating fatal voltage error
UnderVoltageTLim = 3;
% current limits
MaxChgCurrentLim = C_rate * 1.5;
MaxDchgCurrentLim = C_rate * 2;
OverCurrentTLim = 6; % time threshold for indicating fatal current error
% temperature limits
HighCellTempLim = 55 + 273.15;
LowCellTempLim = -20 +273.15;
% voltage sensor fault limit
dVSensorThld = 0.05;

%% SoC Estimation
Ts = 1; % sample time

EnBalVoltageThld = 0.008 ;
ExBalVoltageThld = 0.004 ;
