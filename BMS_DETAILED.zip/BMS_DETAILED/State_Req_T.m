classdef State_Req_T < Simulink.IntEnumType
  enumeration
    Charging(1)
    Driving(2)
    Balancing(3)
    Idle(4)
  end
end 