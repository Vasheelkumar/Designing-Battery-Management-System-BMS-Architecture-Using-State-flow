classdef BMS_State_T < Simulink.IntEnumType
  enumeration
    Charging(1)
    Driving(2)
    Balancing(3)
    Idle(4)
    Fault(5)
  end
end 